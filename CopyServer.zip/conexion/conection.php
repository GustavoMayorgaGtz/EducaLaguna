<?php
   
   
     //   SERVIDOR
     $host = "localhost";
     $dbname = "id20668019_dbeducalaguna";
     $usuario= "id20668019_usereduca";
     $contrasenia = "x@]j88JnSq[~A&St";
            
        try {
                $conectarDB = new PDO("mysql:host=$host;dbname=$dbname", $usuario, $contrasenia);
                $conectarDB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $conectarDB->exec("set names utf8");
                return $conectarDB;
            }
        catch(PDOException $error)
            {
                $_SESSION["mensaje"]="alertify.error('Error en la conexión, revisa tu conexión a internet.')";
                header("Location: index.php");
            }
    

?>