# Documentacion mediadur
### Ambiente
> EL ambiente del proyecto es importante por lo cual deberás checar que puedas correr:
PHP, Mysql.
### Carpetas
> En la arquitectura del proyecto quedaron la siguientes carpetas

| Estructura | Concepto |
| ------ | ------ |
| api |parte de la plantilla|
| BD |Este folder tiene el script de la base de datos del proyecto|
| css |parte de la plantilla|
| fonts |parte de la plantilla|
| js | parte de la plantilla|
| php | parte de la plantilla|
| resources | parte de la plantilla|
| rs-plugin | parte de la plantilla|
| Tabs |Es lo que comúnmente se conoce como el apartado de las view, ya que contiene este: - css - img - las vistas|
| index | parte de la plantilla|

### Tabs
Se recomienda hacer un search and replace, ya que actualmente no está implementado el archivo de configuración.
buscar:
```sh
mysqli_connect
```
Esta carpeta en particular tiene varios elementos y carpetas:
- css 
  Esta carpeta contiene estilos.
- img
  Esta carpeta contiene imágenes que son utilizadas como recurso.
- subMediaDUR
  Esta es una carpeta que contiene
 Pantalla principal que requería login para acceder a submenús de vistas html que no llevan configuración php:
      - principal (Este es php y requiere configuración)
      - abuso sexual infantil
      - Acoso escolar
      - Maltrato infantil
      - Mochila segura
      - Anexos (Este no se encuentra en el mismo directorio pero se manda a llamar desde esa ventana).
anexos
Este es un archivo php que se necesita configurar
Existen dos archivos de login,entre otros archivos php los cuales requieren configuración.


> more info, please contact +52 8714078453
