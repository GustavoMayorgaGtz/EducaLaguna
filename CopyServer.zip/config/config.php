<?php
class Configuracion {
    /*
    ATENCIOOOOON
    Aqui se definen las variables globales que se usaran en caso de usar peticiones o usar el servidor 
    */
    public static array $DATA = [
        'host' => 'https://educalagunas.000webhostapp.com'
    ];
}
?>